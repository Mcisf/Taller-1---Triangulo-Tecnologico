package com.example.taller1computacionmovil.Datos

class Data {
    class Destino(
        val nombre: String?,
        val pais: String?,
        val categoria: String?,
        val plan: String?,
        val precio: String?
    )
    class FavoritosManager {
        companion object {
            val favoritos = ArrayList<String>()

            fun agregarFavorito(destino: String) {
                favoritos.add(destino)
            }

            fun obtenerFavoritos(): List<String> {
                return favoritos
            }
        }
    }
}