package com.example.taller1computacionmovil.Logica

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.taller1computacionmovil.Datos.Data
import com.example.taller1computacionmovil.R
import com.google.gson.GsonBuilder
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query


class descripcionDestinos : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_descripcion_destinos)

        val destinoElegido = intent.getStringExtra("destino")
        val pais = intent.getStringExtra("paisDescripcion")
        val categoria = intent.getStringExtra("cateoriaDescripcion")
        val plan = intent.getStringExtra("planDescripcion")
        val precio = intent.getStringExtra("precioDescripcion")
        val tituloDescripcion: TextView = findViewById(R.id.tituloDescripcion)
        val paisDescripcion: TextView = findViewById(R.id.paisDescripcion)
        val categoriaDescripcion: TextView = findViewById(R.id.categoriaDescripcion)
        val planDescripcion: TextView = findViewById(R.id.planDescripcion)
        val precioDescripcion: TextView = findViewById(R.id.precioDescripcion)

        tituloDescripcion.text = destinoElegido
        paisDescripcion.text = pais
        categoriaDescripcion.text = categoria
        planDescripcion.text = plan
        precioDescripcion.text = "USD "+ precio

        val botonDescripcion:Button = findViewById(R.id.botonDescripcion)
        botonDescripcion.setOnClickListener{
            val destino = destinoElegido ?: ""
            val favoritos = Data.FavoritosManager.obtenerFavoritos()
            var existe = false
            for (i in 0 until favoritos.size){
                if(favoritos[i] == destinoElegido){
                    existe = true
                }
            }
            if(existe == true){
                Toast.makeText(this, "ya esta en Favoritos", Toast.LENGTH_SHORT).show()
                botonDescripcion.visibility = View.GONE
            }
            else{
                Data.FavoritosManager.agregarFavorito(destino)
                Toast.makeText(this, "Añadido a Favoritos", Toast.LENGTH_SHORT).show()
                botonDescripcion.visibility = View.GONE
            }

        }

        if (destinoElegido != null) {
            obtenerClima(destinoElegido)
        }

    }

     fun obtenerClima(ciudad: String) {

        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/data/2.5/")
            .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))

        .build()

        val temperaturaDescripcion:TextView = findViewById(R.id.temperaturaDescripcion)
        val apiInterface = retrofit.create(ApiInterface::class.java)


        val call = apiInterface.getWeatherData(ciudad, "metric", "a34dfeff247b76d0c40d7e0bb9e68932")

         call.enqueue(object : Callback<WeatherResponse> {
             override fun onResponse(call: Call<WeatherResponse>, response: Response<WeatherResponse>) {
                 if (response.isSuccessful)
                 {
                     val weatherResponse = response.body()
                     val temperatura = weatherResponse?.main?.temp
                     temperaturaDescripcion.text = "Temperatura: $temperatura °C"
                 } else {
                     Toast.makeText(this@descripcionDestinos, "Error al obtener el clima. Código de estado: ${response.code()}", Toast.LENGTH_LONG).show()
                 }
             }

             override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {
                 Log.e("Error de red", t.message ?: "Error desconocido")
                 Toast.makeText(this@descripcionDestinos, "Error de red. Por favor, verifica tu conexión a internet.", Toast.LENGTH_LONG).show()
             }
         })

    }

    interface ApiInterface {
        @GET("weather")
        fun getWeatherData(@Query("q") city: String, @Query("units") units: String, @Query("appid") apiKey: String): Call<WeatherResponse>
    }

    data class WeatherResponse(val main: Main)
    data class Main(val temp: Double)
}
