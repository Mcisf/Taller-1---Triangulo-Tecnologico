package com.example.taller1computacionmovil.Logica

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.taller1computacionmovil.Datos.Data
import com.example.taller1computacionmovil.R
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream

class favoritos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_favoritos)

        val listaFavoritos:ListView = findViewById(R.id.listaFavoritos)
        val favoritos = Data.FavoritosManager.obtenerFavoritos()
        val adaptador = ArrayAdapter(this,
            android.R.layout.simple_list_item_1,
            favoritos)

        listaFavoritos.adapter = adaptador
        val json = JSONObject(loadJSONFromAsset())
        val destinosJson = json.getJSONArray("destinos")

        listaFavoritos.setOnItemClickListener{parent,view, position, id ->
        val destinoElegido = favoritos[position]
        val intent = Intent(this, descripcionDestinos::class.java)
        intent.putExtra("destino", destinoElegido)
        for(i in 0 until destinosJson.length()){
            val jsonObject = destinosJson.getJSONObject(i)
            if(jsonObject.getString("nombre")== destinoElegido){
                val paisDescripcion = jsonObject.getString("pais")
                val categoriaDescripcion = jsonObject.getString("categoria")
                val planDescripcion = jsonObject.getString("plan")
                val precioDescripcion = jsonObject.getString("precio")
                intent.putExtra("paisDescripcion", paisDescripcion)
                intent.putExtra("cateoriaDescripcion", categoriaDescripcion)
                intent.putExtra("planDescripcion", planDescripcion)
                intent.putExtra("precioDescripcion", precioDescripcion)
            }
        }
        startActivity(intent)

        }
    }

    fun loadJSONFromAsset(): String? {
        var json: String? = null
        try {
            val isStream: InputStream = assets.open("destinos.json")
            val size:Int = isStream.available()
            val buffer = ByteArray(size)
            isStream.read(buffer)
            isStream.close()
            json = String(buffer, Charsets.UTF_8)
        } catch (ex: IOException) {
            ex.printStackTrace()
            return null
        }
        return json
    }
}