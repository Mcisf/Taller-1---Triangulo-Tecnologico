package com.example.taller1computacionmovil.Logica

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Spinner
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.taller1computacionmovil.Datos.Data
import com.example.taller1computacionmovil.R

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val spinnerCategorias: Spinner = findViewById(R.id.spinnerCategorias)
        val botonExplorar : Button = findViewById(R.id.exlplorarDestinos)
        val botonFavoitos: Button = findViewById(R.id.favoritos)
        val botonRecomendaciones: Button = findViewById(R.id.recomendaciones)

        botonExplorar.setOnClickListener{
            val categoriaElegida = spinnerCategorias.selectedItem.toString()
            val intent = Intent(this, ListaDestinos::class.java)
            intent.putExtra("Categoria", categoriaElegida)
            startActivity(intent)
        }

        botonFavoitos.setOnClickListener{
            val intent = Intent(this, favoritos::class.java)
            startActivity(intent)
        }

        botonRecomendaciones.setOnClickListener{
            val intent = Intent(this, Recomendacion::class.java )
            startActivity(intent)
        }

    }
}