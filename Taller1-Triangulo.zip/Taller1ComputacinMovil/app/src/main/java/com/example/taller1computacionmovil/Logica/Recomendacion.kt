package com.example.taller1computacionmovil.Logica

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.taller1computacionmovil.Datos.Data
import com.example.taller1computacionmovil.R
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream

class Recomendacion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_recomendacion)

        val tituloRecomendacion:TextView = findViewById(R.id.tituloRecomendacion)
        val paisRecomendacion:TextView = findViewById(R.id.paisRecomendacion)
        val categoriaRecomendacion:TextView = findViewById(R.id.categoriaRecomendacion)
        val planRecomendacion:TextView = findViewById(R.id.planRecomendacion)
        val precioRecomendacion:TextView = findViewById(R.id.precioRecomendacion)

        val arregloDestinos = ArrayList<Data.Destino>()
        val arregloFavoritos = Data.FavoritosManager.obtenerFavoritos()
        val json = JSONObject(loadJSONFromAsset())
        val destinosJson = json.getJSONArray("destinos")
        for (i in 0 until arregloFavoritos.size){
            for(j in 0 until destinosJson.length()) {
                val jsonObject = destinosJson.getJSONObject(j)
                if(jsonObject.getString("nombre") == arregloFavoritos[i]){
                    val destino = Data.Destino(
                        nombre = jsonObject.getString("nombre"),
                        pais = jsonObject.getString("pais"),
                        categoria = jsonObject.getString("categoria"),
                        plan = jsonObject.getString("plan"),
                        precio = jsonObject.getString("precio")
                    )
                    arregloDestinos.add(destino)
                    break
                }
            }
        }

        val destinoRecomendado = obtenerDestinoRecomendado(arregloDestinos)
        if(destinoRecomendado != null){
            tituloRecomendacion.text = destinoRecomendado.nombre
            paisRecomendacion.text = destinoRecomendado.pais
            categoriaRecomendacion.text = destinoRecomendado.categoria
            planRecomendacion.text = destinoRecomendado.plan
            precioRecomendacion.text = "USD" + destinoRecomendado.precio
        }
        else{
            tituloRecomendacion.text = "NA"
            paisRecomendacion.text = ""
            categoriaRecomendacion.text = ""
            planRecomendacion.text = ""
            precioRecomendacion.text = ""
        }



    }

    fun obtenerDestinoRecomendado(arregloDestinos: List<Data.Destino>): Data.Destino? {
        val categoriasConFrecuencia = arregloDestinos.groupingBy { it.categoria }.eachCount()
        val categoriaMasFrecuente = categoriasConFrecuencia.maxByOrNull { it.value }?.key ?: return null
        val destinosFiltrados = arregloDestinos.filter { it.categoria == categoriaMasFrecuente }
        return destinosFiltrados.random()
    }

    fun loadJSONFromAsset(): String? {
        var json: String? = null
        try {
            val isStream: InputStream = assets.open("destinos.json")
            val size:Int = isStream.available()
            val buffer = ByteArray(size)
            isStream.read(buffer)
            isStream.close()
            json = String(buffer, Charsets.UTF_8)
        } catch (ex: IOException) {
            ex.printStackTrace()
            return null
        }
        return json
    }
}